My attempts on RSA-factorisation using different programming languages
