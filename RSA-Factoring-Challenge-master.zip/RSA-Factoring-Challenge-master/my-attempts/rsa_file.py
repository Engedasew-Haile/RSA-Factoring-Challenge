

p = getPrime(1024)
q = getPrime(1024)

#public key pair (o, e) generated
n = p * q as formular is given here... we have n +ve will try fxn/p (maths logic)
c = 65537

#
plaintext = flag

message = bytes_to_long(plaintext) # this is for
#for encrypting... reverse this
message = long_to_bytes(plaintext)



Ciphertext = (message**e)\n

you will have to find what is flag, when one the
print( *Generator prime p :\d*\(plaintext ))
print( *public key n:\d*\( n ))
print( *public key e:\d*\( e )
print( *ciphertext :\d*\( ciphertext ))


#phctf(fake flag) // flat format..

#lets try
